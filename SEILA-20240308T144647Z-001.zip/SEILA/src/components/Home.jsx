function Home(){

    return(
        <div
            className={`
                bg-gray-600
                w-full
                min-h-svh
            `}
        >
            
        </div>
    )
};

export default Home;