import '../css/galery.css'
function Galery(){
    return(
        <div className='center'>
            <div className='buttonLeft'></div>
            <div className='display'></div>
            <div className='buttonRight'></div>
        </div>
    )
}