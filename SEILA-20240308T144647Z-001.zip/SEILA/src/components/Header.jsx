import React from 'react';
import '../css/header.css'
function Header(){
    return(
        <div className='menu'>
            <div className='mart'>Marte</div>
            <div className='univers'>Universo</div>
            <div className='earth'>Terra</div>
        </div>
    )
};

export default Header;